/*
    File: Shape3D.java
    
    Programmer's Name: Rohan Shanbhag Section U04 COP 3337
    
    I affirm that this program is entirely my own work and none of it is the 
    work of any other person.
    Rohan Shanbhag 

    This class represents a 3D shape. It consists of methods that get the 
    distance of the center of the shape from the origin, a toString method that
    calls the toString method of the Point3D class to display the coordinates of
    the center, and 2 abstract methods called getVolume and getSurfaceArea. It 
    also implements the comparable interface so that shape objects can be 
    ordered by volume (descending order). 
*/
package shapes3d;

/**
 * This class models a 3D shape. There are 2 abstract methods (getVolume and
 * getSurfaceArea) that will be further implemented in the derived subclasses.
 * It also consists of methods that get the distance of the center of the shape
 * from the origin and a toString method that calls the toString method of the
 * Point3D class to display the coordinates of the center. This class implements
 * the comparable interface to sort the shape objects that extend this class by
 * descending volume.
 */
public abstract class Shape3D implements Comparable
{
    private Point3D center ; 
    // Declaring a Point3D object that is pointed to by center.
    
    /**
     * This constructor initializes the Point3D object instance variable's 
     * center with the x, y, and z coordinates that will be passed in through 
     * the parameter variables userX, userY, and userZ. 
     * @param userX the x-coordinate of the center specified in the tester.
     * @param userY the y-coordinate of the center specified in the tester.
     * @param userZ the z-coordinate of the center specified in the tester.
     */
    public Shape3D(int userX, int userY, int userZ)
    {
        center = new Point3D(userX, userY, userZ) ; 
        /*
        Initializes the center Point3D object with userX as the x-coordinate, 
        userY as the y-coordinate, and userZ as the z-coordiante. 
        */
    }
    
    /**
     * This method returns the string representation of the coordinates of the 
     * center. 
     * @return the coordinates of the center.
     */
    public String toString()
    {
        String centerString = center.toString() ; 
        /*
        Calling the toString method of the Point3D class and storing the string
        returned in string centerString. 
        */
        return centerString ; 
        // Returns the string representation of the center. 
    }
    
    /**
     * This method gets the distance of the center of the shape from the origin
     * and returns it.
     * @return the distance of the center of the shape from the origin. 
     */
    public double getDistance()
    {
        double distance ; 
        // Creating local variable distance to store the value of the distance.
        double xCoordinate = center.getXCoordinate() ; 
        /*
        Creating local variable xCoordiante to store the value of the 
        x-coordinate of the center by calling the getXCoordinate method of the
        Point3D class. 
        */
        double yCoordinate = center.getYCoordinate() ; 
        /*
        Creating local variable yCoordiante to store the value of the 
        y-coordinate of the center by calling the getYCoordinate method of the
        Point3D class. 
        */
        double zCoordinate = center.getZCoordinate() ;  
        /*
        Creating local variable zCoordiante to store the value of the 
        z-coordinate of the center by calling the getZCoordinate method of the
        Point3D class. 
        */
        distance = Math.sqrt((Math.pow(xCoordinate, 2)) + 
                      (Math.pow(yCoordinate, 2)) + (Math.pow(zCoordinate, 2))) ;
        /*
        The distance of the center of the shape from the origin is the the 
        square root of (x^2 + y^2 + z^2). Using the Math class methods pow
        and sqrt to perform the calculation listed above.
        */
        return distance ; 
        // Returns the distance of the center of the shape from the origin. 
    }
    
    /**
     * This method sorts the shape objects in order of descending volume. 
     * @param otherObject the shape object that is being compared to.
     * @return 1 if the volume of the shape is less than the volume of the 
     * shape being compared to, -1 if the volume of the shape is greater than 
     * the volume of the shape being compared to, and 0 if the volumes of both
     * shapes are equal. 
     */
    public int compareTo(Object otherObject)
    {
        Shape3D other = (Shape3D)otherObject ;
        // Explicity downcasting the Big O object to a Shape3D object.  
        if (this.getVolume() < other.getVolume())
        /*
        If the volume of the shape is less than the volume of the shape being
        compared to.
        */
        {
            return 1 ;
            // Return 1.
        }
        else if (this.getVolume() > other.getVolume())
        /*
        If the volume of the shape is greater than the volume of the shape being
        compared to.
        */
        {
            return -1 ;
            // Return -1.
        }
        else
        //Else, if the volumes are equal.
        {		
            return 0 ;
            // Return 0   
        }
    }
    
    /**
     * This is an abstract method gets the volume of the shape. Will be 
     * implemented later on by the derived subclasses of Shape3D.
     * @return the volume of the shape
     */
    public abstract double getVolume() ; 
    
    /**
     * This is an abstract method gets the surface area of the shape. Will be 
     * implemented later on by the derived subclasses of Shape3D.
     * @return the surface area of the shape.
     */
    public abstract double getSurfaceArea() ; 
    
    /**
     * This is an abstract method gets the class name of the shape. Will be 
     * implemented later on by the derived subclasses of Shape3D.
     * @return the class name of the shape in string format.
     */
    public abstract String getClassName() ; 
}
