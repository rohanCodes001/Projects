/*
    File: DistanceMeasurer.java
    
    Programmer's Name: Rohan Shanbhag Section U04 COP 3337
    
    I affirm that this program is entirely my own work and none of it is the 
    work of any other person.
    Rohan Shanbhag 

    This class implements the comparator interface so that shape objects can
    be measured based on their distances from the origin in ascending order.
*/
package shapes3d;

import java.util.Comparator;

/**
 * This class is implemented so that shape objects can be measured based on 
 * ascending distance from the origin. It implements the comparator interface
 * and overrides the compare method to accomplish the task above.
 */
public class DistanceMeasurer implements Comparator 
{
    /**
     * This method is overridden so that shape objects can be measured based
     * on their distance from the origin. 
     * @param otherObject the first object to be measured.
     * @param otherObjectTwo the second object to be measured.
     * @return 1 if the distance of the first shape is greater than the distance 
     * of the second shape, -1 if the distance of the first shape is less than 
     * the distance of the second shape, and 0 if the distances of both
     * shapes are equal.
     */
    public int compare(Object otherObject, Object otherObjectTwo)
    {
        Shape3D other = (Shape3D)otherObject ;
        // Explicitly downcating the first object to a shape object.
        Shape3D otherTwo = (Shape3D)otherObjectTwo ;
        // Explicitly downcating the second object to a shape object.
        if (other.getDistance() > otherTwo.getDistance())
        /*
        If the distance of the first shape is greater than the distance 
        of the second shape.
        */
        {
            return 1 ;
            /*
            Return 1 so that the shape with the greatest distance is the last
            one when Arrays.sort(array, object-name) is called in the main class
            .
            */
        }
        else if (other.getDistance() < otherTwo.getDistance())
        /*
        If the distance of the first shape is less than the distance 
        of the second shape.
        */
        {
            return -1 ;
            /*
            Return -1 so that the shape with the least distance is the first
            one when Arrays.sort(array, object-name) is called in the main class
            .
            */
        }
        else
        // Else, if the distances are equal.
        {		
            return 0 ;
            // Return 0.
        }
    }
}
