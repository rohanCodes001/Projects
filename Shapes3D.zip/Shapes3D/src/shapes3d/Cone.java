/*
    File: Cone.java
    
    Programmer's Name: Rohan Shanbhag Section U04 COP 3337
    
    I affirm that this program is entirely my own work and none of it is the 
    work of any other person.
    Rohan Shanbhag 

    This class represents a 3D cone. It extends the Shape3D class since it is
    a 3D shape and one of the derived subclasses. It implements the abstract
    methods getVolume and getSurfaceArea based on the formula of a cone's 
    volume and surface area. It also overrides the toString method with its
    own version of it. Lastly, it implements the abstract method getClassName
    so that it can return the name of its own class.
*/
package shapes3d;

/**
 * This class models a 3D shape known as a cone. It extends the Shape3D class 
 * since it is a 3D shape and one of the derived subclasses. It implements the 
 * abstract methods getVolume and getSurfaceArea based on the formula of a 
 * cone's volume and surface area. It also overrides the toString method with 
 * its own version of it. Lastly, it implements the abstract method getClassName
 * so that it can return the name of its own class.
 */
public class Cone extends Shape3D 
{
    private int radius ; 
    // This is an instance variable that represents the radius of a cone.
    private int height ; 
    // This is an instance variable that represents the height of a cone.
    private String className ; 
    // This is an instance variable that represents the name of this class.
    
    /**
     * This constructor initializes the coordinates of the center of the cone, 
     * the radius, the height, and the class name of the Cone class. 
     * @param userX the x-coordinate of the center of the cone specified in the 
     * tester.
     * @param userY the y-coordinate of the center of the cone specified in the 
     * tester.
     * @param userZ the z-coordinate of the center of the cone specified in the
     * tester.
     * @param userRadius the radius of the cone specified in the tester.
     * @param userHeight the height of the cone specified in the tester.
     */
    public Cone(int userX, int userY, int userZ, int userRadius, int userHeight)
    {
        super(userX, userY, userZ) ; 
        /*
        Calling the superclass Shape3D constructor to pass in the x, y, and z
        coordinates of the cone through the parameter variables userX, userY,
        and userZ. 
        */
        radius = userRadius ; 
        /*
        Initializing the value of the radius to the value specifed in the 
        tester class through parameter variable userRadius.
        */
        height = userHeight ; 
        /*
        Initializing the value of the height to the value specifed in the 
        tester class through parameter variable userHeight.
        */
        className = "Cone" ; 
        // Initializing the className to "Cone" in string format. 
    }
    
    /**
     * This method computes the volume of the cone and returns it.
     * @return the volume of the cone.
     */
    public double getVolume()
    {
        double volume ; 
        // Creating a local variable to store the value for the volume.
        volume = (Math.PI * Math.pow(radius, 2) * height) / 3 ; 
        /*
        The formula for the volume of a cone is (3.14(pi) * radius^2 * height)/
        / 3. The formula uses the Math.pow method to perform the calculation 
        above and Math.PI represents the full value of pi. 
        */
        return volume ; 
        // Returning the value of the volume of the cone. 
    }
    
    /**
     * This method computes the surface area of the cone and returns it.
     * @return the surface area of the cone.
     */
    public double getSurfaceArea()
    {
        double surfaceArea ;
        /*
        Creating a local variable to store the value for the surface area of the
        cone.
        */
        surfaceArea = (Math.PI * radius) * (radius + Math.sqrt(Math.pow(radius, 
                       2) + Math.pow(height, 2))) ; 
        /*
        The formula for the surface area of a cone is ∏r(r + square root of
        (r^2 + h^2)). The formula uses the Math.pow method and the Math.sqrt 
        method to perform the calculation above and Math.PI represents the full
        value of pi. 
        */
        return surfaceArea ; 
        // Returns the value of the surface area of the cone. 
    }
    
    /**
     * This method returns the name of the class in string format. 
     * @return the class name of the class.
     */
    public String getClassName()
    {
        return className ; 
        // Returns the class name of the class.
    }
    
    /**
     * This method overrides the toString method of the Shape3D class to 
     * return not just the coordinates of the center but to also return all of 
     * the other values and the class name as well. 
     * @return the class name followed by the coordinates of the center followed
     * by the other values of the cone (radius and height).
     */
    public String toString()
    {
        return this.getClassName() + "\n" + super.toString() + "\n" + 
                "Radius: " + radius + " Height: " + height ;  
        /*
        Returns the class name followed by the coordinates of the center 
        followed by the other values of the cone (radius and height).
        */
    }
}
