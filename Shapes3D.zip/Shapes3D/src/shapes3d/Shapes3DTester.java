/*
    File: Shapes3DTester.java
    
    Programmer's Name: Rohan Shanbhag Section U04 COP 3337
    
    I affirm that this program is entirely my own work and none of it is the 
    work of any other person.
    Rohan Shanbhag 

    This class is the tester class. It gathers all of the hardwired data for the
    shape objects created. An array of shape objects is then created and sorted
    using the Arrays.sort method and the overloaded Arrays.sort method. The 
    array is sorted by descending volume and then later sorted by ascending 
    distance form the origin. 
*/
package shapes3d;

import java.util.Arrays;

/**
 * This class is the tester class. It gathers all of the hardwired data for the
 * shape objects created. An array of shape objects is then created and sorted
 * using the Arrays.sort method and the overloaded Arrays.sort method. The 
 * array is sorted by descending volume and then later sorted by ascending 
 * distance form the origin. 
 */
public class Shapes3DTester 
{
    public static void main(String[] args) 
    {
        Cone obj = new Cone(-5, 4, -1, 11, 15) ; 
        // Creating a Cone object and passing in the hardwired input.
        Sphere obj2 = new Sphere(2, 5, 8, 14) ; 
        // Creating a Sphere object and passing in the hardwired input.
        Cylinder obj3 = new Cylinder(-3, -7, 5, 14, 12) ; 
        // Creating a Cylinder object and passing in the hardwired input.
        Parallelepiped obj4 = new Parallelepiped(7, 16, 9, 19, 9, 13) ; 
        // Creating a Parallelepiped object and passing in the hardwired input.
  
        Shape3D arr[] = {obj, obj2, obj3, obj4} ; 
        // Creating an array of shapes.
        String displayString = "" ; 
        /*
        An empty string that will be used to display the array and its contents
        like coordiantes of the center, surface area, and other data values like
        radius, height, etc.....
        */
        for(int i = 0 ; i < arr.length ; i++)
        // Traversing the array.
        {
            displayString += arr[i].toString() + " " + "\n" + "Surface Area: " + 
               arr[i].getSurfaceArea() + " " + "\n" + "------------------------"
                        + "---------------------------" + "\n" ;
            /*
            Calling the toString method of the shape objects polymorphically to
            print out the different data values of the different shapes. The 
            same applies for the getSurfaceArea method. The results are then
            concatenated and stored in displayString. 
            */
        }
        System.out.println(displayString);
        // Printing out the array to the user.
        
        System.out.println("Array sorted by volume: ") ; 
        Arrays.sort(arr) ; 
        /*
        Calling the Arrays class static method Arrays.sort to sort the array by
        descending volume. 
        */
        String displayStringTwo = "" ;
        /*
        An empty string that will be used to display the sorted array in order
        of descending volume along with the class name of the sorted shape 
        objects as well. 
        */
        for(int i = 0 ; i < arr.length; i++)
        // Traversing the array.
        {
            displayStringTwo += arr[i].getClassName() + " " +  "Volume: " + 
                arr[i].getVolume() + " " + "\n" ; 
            /*
            Calling the getClassName and getVolume method of the shape objects
            polymorphically to print out the different volumes of the shapes 
            along with the differing class names. The results are then
            concatenated and stored in displayStringTwo. 
            */
        }
        System.out.println(displayStringTwo);
        // Printing out the sorted array in order of descending volume.
        
        System.out.println("Array sorted by distance from origin: ") ; 
        DistanceMeasurer measurer = new DistanceMeasurer() ; 
        /*
        Creating a DistanceMeasurer object so that the shape objects can be
        sorted by order of ascending distance from the origin. 
        */
        Arrays.sort(arr, measurer) ; 
        /*
        Calling the overloaded Arrays.sort method to sort the shape objects by
        order of ascending distance.
        */
        String displayStringThree = "" ; 
        /*
        An empty string that will be used to display the sorted array in order
        of ascending distance along with the class name of the sorted shape 
        objects as well. 
        */
        for(int i = 0 ; i < arr.length; i++)
        // Traversing the array.
        {
            displayStringThree += arr[i].getClassName() + " " +  "Distance: " + 
                arr[i].getDistance() + " " + "\n" ; 
            /*
            Calling the getClassName polymorphically to display the differing 
            class names. The getDistance method is then called to display to the
            varying distances of the shape objects. The results are the 
            concatenated and stored in displayStringThree. 
            */
        }
        System.out.println(displayStringThree) ; 
        // Printing out the sorted array in order of ascending distance.
    }
}
