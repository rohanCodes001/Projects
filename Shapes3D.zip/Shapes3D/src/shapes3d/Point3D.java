/*
    File: Point3D.java
    
    Programmer's Name: Rohan Shanbhag Section U04 COP 3337
    
    I affirm that this program is entirely my own work and none of it is the 
    work of any other person.
    Rohan Shanbhag 

    This class represents a point on a 3D plane This class has accessor methods
    that retrieve the x, y, and z coordinates of a point. This class also has
    a toString method that prints out the x, y and z coordinates of a point in 
    string format. 
*/
package shapes3d;

/**
 * This class models a point on a 3 dimensional plane. This class has methods
 * that retrieve the x, y, and z coordinates of a point. This class also 
 * has a toString method that prints out the x, y and z coordinates of a point 
 * in string format. 
 */
public class Point3D 
{
    private int xCoordinate ; 
    // The x-coordinate of a point in a 3D plane.
    private int yCoordinate ;
    // The y-coordinate of a point in a 3D plane.
    private int zCoordinate ; 
    // The z-coordinate of a point in a 3D plane.
    
    /**
     * This constructor initializes the coordinates to the values of the 
     * hardwired ones in the tester class.
     * @param userX the user-specified / hardwired x-coordinate.
     * @param userY the user-specified / hardwired y-coordinate.
     * @param userZ the user-specified / hardwired z-coordinate.
     */
    public Point3D(int userX, int userY, int userZ)
    {
        xCoordinate = userX ;
        /*
        Sets the instance variable xCoordinate to the value of the parameter
        variable userX.
        */
        yCoordinate = userY ;
        /*
        Sets the instance variable yCoordinate to the value of the parameter
        variable userY.
        */
        zCoordinate = userZ ; 
        /*
        Sets the instance variable zCoordinate to the value of the parameter
        variable userZ.
        */
    }
    
    /**
     * This method returns the x, y, and z coordinates of a point as a string. 
     * @return the x,y and z coordinates of a point in string format. 
     */
    public String toString()
    {
        return "X Coordinate: " + xCoordinate + " Y Coordinate: " + yCoordinate 
                + " Z Coordinate: " + zCoordinate ; 
    }
    
    /**
     * This is a method that retrieves the x-coordinate of a point. 
     * @return the x-coordinate of a point.
     */
    public int getXCoordinate()
    {
        return xCoordinate ; 
        // Returns the x-coordiante of the point.
    }
    
    /**
     * This is a method that retrieves the y-coordinate of a point. 
     * @return the y-coordinate of a point.
     */
    public int getYCoordinate()
    {
        return yCoordinate ; 
        // Returns the y-coordiante of the point.
    }
    
    /**
     * This is a method that retrieves the z-coordinate of a point. 
     * @return the z-coordinate of a point.
     */
    public int getZCoordinate()
    {
        return zCoordinate ; 
        // Returns the z-coordiante of the point.
    }     
}
