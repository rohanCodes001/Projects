/*
    File: Sphere.java
    
    Programmer's Name: Rohan Shanbhag Section U04 COP 3337
    
    I affirm that this program is entirely my own work and none of it is the 
    work of any other person.
    Rohan Shanbhag 

    This class represents a 3D sphere. It extends the Shape3D class since it is
    a 3D shape and one of the derived subclasses. It implements the abstract
    methods getVolume and getSurfaceArea based on the formula of a sphere's 
    volume and surface area. It also overrides the toString method with its
    own version of it. Lastly, it implements the abstract method getClassName
    so that it can return the name of its own class.
*/
package shapes3d;

/**
 * This class models a 3D shape known as a sphere. It extends the Shape3D class 
 * since it is a 3D shape and one of the derived subclasses. It implements the 
 * abstract methods getVolume and getSurfaceArea based on the formula of a 
 * sphere's volume and surface area. It also overrides the toString method with 
 * its own version of it. Lastly, it implements the abstract method getClassName
 * so that it can return the name of its own class.
 */
public class Sphere extends Shape3D 
{  
    private int radius ;
    // This is an instance variable that represents the radius of a sphere.
    private String className ; 
    // This is an instance variable that represents the name of this class.
    
   /**
     * This constructor initializes the coordinates of the center of the sphere, 
     * the radius, and the class name of the Sphere class. 
     * @param userX the x-coordinate of the center of the sphere specified in 
     * the tester.
     * @param userY the y-coordinate of the center of the sphere specified in 
     * the tester.
     * @param userZ the z-coordinate of the center of the sphere specified in 
     * the tester.
     * @param userRadius the radius of the sphere specified in the tester.
     */
    public Sphere(int userX, int userY, int userZ, int userRadius)
    {
        super(userX, userY, userZ) ;
         /*
        Calling the superclass Shape3D constructor to pass in the x, y, and z
        coordinates of the sphere through the parameter variables userX, userY,
        and userZ. 
        */
        radius = userRadius ; 
        /*
        Initializing the value of the radius to the value specifed in the 
        tester class through parameter variable userRadius.
        */
        className = "Sphere" ; 
        // Initializing the className to "Sphere" in string format. 
    }
    
    /**
     * This method computes the volume of the sphere and returns it.
     * @return the volume of the sphere.
     */
    public double getVolume()
    {
        double volume ;
        // Creating a local variable to store the value for the volume.
        volume = (4.0 / 3) * (Math.PI) * (Math.pow(radius, 3)) ; 
        /*
        The volume of a sphere is (4 / 3) * ∏ * r^3. The formula uses the 
        Math.pow method to perform the calculation above and Math.PI represents 
        the full value of pi. 
        */
        return volume ; 
        // Returning the value of the volume of the sphere. 
    }
    
    /**
     * This method computes the surface area of the sphere and returns it.
     * @return the surface area of the sphere.
     */
    public double getSurfaceArea()
    {
        double surfaceArea ; 
        /*
        Creating a local variable to store the value for the surface area of the
        sphere.
        */
        surfaceArea = 4.0 * (Math.PI) * (Math.pow(radius, 2)) ; 
        /*
        The formula for the surface area of a sphere is 4 * ∏ * r^2. 
        The formula uses the Math.pow method to perform the calculation above 
        and Math.PI represents the full value of pi. 
        */
        return surfaceArea ; 
        // Returns the value of the surface area of the sphere. 
    }
    
    /**
     * This method returns the name of the class in string format. 
     * @return the class name of the class.
     */
    public String getClassName()
    {
        return className ; 
        // Returns the class name of the class.
    }
    
    /**
     * This method overrides the toString method of the Shape3D class to 
     * return not just the coordinates of the center but to also return all of 
     * the other values and the class name as well. 
     * @return the class name followed by the coordinates of the center followed
     * by the other values of the sphere (radius).
     */
    public String toString()
    {
        return this.getClassName()+ "\n" + super.toString() +"\n" + "Radius: " + 
                radius ; 
        /*
        Returns the class name followed by the coordinates of the center 
        followed by the other values of the sphere (radius).
        */
    }
}
