/*
    File: Parallelepiped.java
    
    Programmer's Name: Rohan Shanbhag Section U04 COP 3337
    
    I affirm that this program is entirely my own work and none of it is the 
    work of any other person.
    Rohan Shanbhag 

    This class represents a 3D parallelepiped. It extends the Shape3D class 
    since it is a 3D shape and one of the derived subclasses. It implements the
    abstract methods getVolume and getSurfaceArea based on the formula of a 
    parallelepiped's volume and surface area. It also overrides the toString 
    method with its own version of it. Lastly, it implements the abstract method 
    getClassName so that it can return the name of its own class.
*/
package shapes3d;

/**
 * This class models a 3D parallelepiped. It extends the Shape3D class 
 * since it is a 3D shape and one of the derived subclasses. It implements the
 * abstract methods getVolume and getSurfaceArea based on the formula of a 
 * parallelepiped's volume and surface area. It also overrides the toString 
 * method with its own version of it. Lastly, it implements the abstract method 
 * getClassName so that it can return the name of its own class.
 */
public class Parallelepiped extends Shape3D
{
    private int length ;
    /*
    This is an instance variable that represents the length of a parallelepiped.
    */
    private int width ; 
    /*
    This is an instance variable that represents the width of a parallelepiped.
    */
    private int height ; 
    /*
    This is an instance variable that represents the height of a parallelepiped.
    */
    private String className ; 
    // This is an instance variable that represents the name of this class.
    
    /**
     * This constructor initializes the coordinates of the center of the 
     * parallelepiped, the length, the width, the height, and the class name of 
     * the Parallelepiped class. 
     * @param userX the x-coordinate of the center of the parallelepiped 
     * specified in the tester.
     * @param userY the y-coordinate of the center of the parallelepiped 
     * specified in the tester.
     * @param userZ the z-coordinate of the center of the parallelepiped 
     * specified in the tester.
     * @param userLength the length of the parallelepiped specified in the 
     * tester.
     * @param userWidth the width of the parallelepiped specified in the 
     * tester.
     * @param userHeight the height of the parallelepiped specified in the 
     * tester.
     */
    public Parallelepiped(int userX, int userY, int userZ, int userLength, 
                          int userWidth, int userHeight)
    {
        super(userX, userY, userZ) ;
        /*
        Calling the superclass Shape3D constructor to pass in the x, y, and z
        coordinates of the parallelepiped through the parameter variables userX, 
        userY, and userZ. 
        */
        length = userLength ; 
        /*
        Initializing the value of the length to the value specifed in the 
        tester class through parameter variable userLength.
        */
        width = userWidth ; 
        /*
        Initializing the value of the width to the value specifed in the 
        tester class through parameter variable userWidth.
        */
        height = userHeight ; 
        /*
        Initializing the value of the height to the value specifed in the 
        tester class through parameter variable userHeight.
        */
        className = "Parallelepiped" ;
        // Initializing the className to "Parallelepiped" in string format.  
    }
    
    /**
     * This method computes the volume of the parallelepiped and returns it.
     * @return the volume of the parallelepiped.
     */
    public double getVolume()
    {
        double volume ; 
        // Creating a local variable to store the value for the volume.
        volume = length * width * height ; 
        /*
        The formula for the volume of a parallelepiped  is the length * width *
        height.
        */
        return volume ; 
        // Returning the value of the volume of the parallelepiped. 
    }
    
    /**
     * This method computes the surface area of the parallelepiped and returns 
     * it.
     * @return the surface area of the parallelepiped.
     */
    public double getSurfaceArea()
    {
        double surfaceArea ; 
        // Creating a local variable to store the value for the surface area.
        surfaceArea = (2 * width * length) + (2 * width * height) + (2 * length 
                       * height) ; 
        /*
        The formula for the surface area of a parallelepiped is (2 * width * 
        length) + (2 * width * height) + (2 * length * height) ; 
        */
        return surfaceArea ; 
        // Returning the value of the surface area of the parallelpiped. 
    }
    
    /**
     * This method returns the name of the class in string format. 
     * @return the class name of the class.
     */
    public String getClassName()
    {
        return className ; 
        // Returns the class name of the class.
    }
    
    /**
     * This method overrides the toString method of the Shape3D class to 
     * return not just the coordinates of the center but to also return all of 
     * the other values and the class name as well. 
     * @return the class name followed by the coordinates of the center followed
     * by the other values of the parallelepiped (length, width, and height).
     */
    public String toString()
    {
        return this.getClassName() + "\n" + super.toString() + "\n" + "Length: " 
                + length + " Width: " + width + " Height: " + height ;  
        /*
        Returns the class name followed by the coordinates of the center 
        followed by the other values of the parallelepiped (length, width, and
        height).
        */
    }
}
