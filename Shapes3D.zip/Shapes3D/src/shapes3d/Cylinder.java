/*
    File: Cylinder.java
    
    Programmer's Name: Rohan Shanbhag Section U04 COP 3337
    
    I affirm that this program is entirely my own work and none of it is the 
    work of any other person.
    Rohan Shanbhag 

    This class represents a 3D cylinder. It extends the Shape3D class since it 
    is a 3D shape and one of the derived subclasses. It implements the abstract
    methods getVolume and getSurfaceArea based on the formula of a cylinder's 
    volume and surface area. It also overrides the toString method with its
    own version of it. Lastly, it implements the abstract method getClassName
    so that it can return the name of its own class.
*/
package shapes3d;

/**
 * This class models a 3D shape known as a cylinder. It extends the Shape3D 
 * class since it is a 3D shape and one of the derived subclasses. It implements 
 * the abstract methods getVolume and getSurfaceArea based on the formula of a 
 * cylinder's volume and surface area. It also overrides the toString method 
 * with its own version of it. Lastly, it implements the abstract method 
 * getClassName so that it can return the name of its own class.
 */
public class Cylinder extends Shape3D 
{
    private int radius ; 
    // This is an instance variable that represents the radius of a cylinder.
    private int height ; 
    // This is an instance variable that represents the height of a cylinder.
    private String className ; 
    // This is an instance variable that represents the name of this class.
    
    /**
     * This constructor initializes the coordinates of the center of the 
     * cylinder, the radius, the height, and the class name of the Cylinder 
     * class. 
     * @param userX the x-coordinate of the center of the cylinder specified in 
     * the tester.
     * @param userY the y-coordinate of the center of the cylinder specified in 
     * the tester.
     * @param userZ the z-coordinate of the center of the cylinder specified in 
     * the tester.
     * @param userRadius the radius of the cylinder specified in the tester.
     * @param userHeight the height of the cylinder specified in the tester.
     */
    public Cylinder(int userX, int userY, int userZ, int userRadius, int 
                    userHeight)
    {
        super(userX, userY, userZ) ;
        /*
        Calling the superclass Shape3D constructor to pass in the x, y, and z
        coordinates of the cylinder through the parameter variables userX, 
        userY, and userZ. 
        */
        radius = userRadius ; 
        /*
        Initializing the value of the radius to the value specifed in the 
        tester class through parameter variable userRadius.
        */
        height = userHeight ; 
        /*
        Initializing the value of the height to the value specifed in the 
        tester class through parameter variable userHeight.
        */
        className = "Cylinder" ; 
        // Initializing the className to "Cylinder" in string format. 
    }
    
    /**
     * This method computes the volume of the cylinder and returns it.
     * @return the volume of the cylinder.
     */
    public double getVolume()
    {
        double volume ; 
        // Creating a local variable to store the value for the volume.
        volume = Math.PI * Math.pow(radius, 2) * height; 
        /*
        The formula for the volume of a cylinder ∏ * r^2 * h is The formula uses 
        the Math.pow method to perform the calculation above and Math.PI 
        represents the full value of pi. 
        */
        return volume ; 
        // Returning the value of the volume of the cylinder. 
    }
    
    /**
     * This method computes the surface area of the cylinder and returns it.
     * @return the surface area of the cylinder.
     */
    public double getSurfaceArea()
    {
        double surfaceArea ; 
        /*
        Creating a local variable to store the value for the surface area of the
        cylinder.
        */
        surfaceArea = (2 * Math.PI * Math.pow(radius, 2)) + (2 * Math.PI * 
                       radius * height) ; 
        /*
        The formula for the surface area of a cylinder is 2 * ∏ * r^2 + 2 * ∏ * 
        r * h. The formula uses the Math.pow method to perform the calculation 
        above and Math.PI represents the full value of pi. 
        */
        return surfaceArea ; 
        // Returns the value of the surface area of the cylinder. 
    }
    
    /**
     * This method returns the name of the class in string format. 
     * @return the class name of the class.
     */
    public String getClassName()
    {
        return className ; 
        // Returns the class name of the class.
    }
    
    /**
     * This method overrides the toString method of the Shape3D class to 
     * return not just the coordinates of the center but to also return all of 
     * the other values and the class name as well. 
     * @return the class name followed by the coordinates of the center followed
     * by the other values of the cylinder (radius and height).
     */
    public String toString()
    {
        return this.getClassName() + "\n" + super.toString() + "\n" + "Radius: " 
                + radius + " Height: " + height ;  
        /*
        Returns the class name followed by the coordinates of the center 
        followed by the other values of the cylinder (radius and height).
        */
    }
}
