/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tictactoe2;

import java.util.Random;
import javax.swing.JOptionPane;

//******************************************************************************
// STUDENT NAME: Rohan Shanbhag
// FIU EMAIL: rshan026@fiu.edu
// CLASS: COP 2210 – Fall 2019
// ASSIGNMENT # 5
// DATE: 12/1/2019
//
// I hereby swear and affirm that this work is solely my own, and not the work 
// or the derivative of the work of someone else, except as outlined in the 
// assignment instructions.
//******************************************************************************
public class TicTacToe2 {

    /**
     * These are the instance variables of the TicTacToe2 class. char[][] arr is
     * a default char array with 3 rows and 3 columns. plyaerCharaceter and
     * computerCharacter get initialized to 'X' or 'O' depending on who goes
     * first. keepPlaying is a boolean that gets set to true in the constructor
     * so that the program runs until either the board is full or 
     * if one of the players win. String name holds the name that the user 
     * inputs in the main class and gets passed to the other methods in this 
     * class as a parameter so that their name can be registered and displayed
     * in the input dialogs. lastToPlay is a character instance variable that 
     * is there to determine whose turn it was before the winning condition is 
     * checked.
     */
    char[][] arr = new char[3][3];
    char playerCharacter = ' ';
    char computerCharacter = ' ';
    boolean keepPlaying;
    String name;
    char lastToPlay = ' ';
    
    /**
     * This is the constructor of the TicTacToe2 class that initializes the
     * value of boolean keepPlaying to true.
     */
    public TicTacToe2() {
        keepPlaying = true;
    }

    /**
     * This is the method randomDecision. This method randomly generates who
     * goes first, the user or the computer. Based on that, instance variables
     * playerCharacter and computerCharacter are set to either 'X' or 'O'
     * depending on who goes first. Then the corresponding methods computer
     * or player are called depending on who goes first.
     * @param userName This parameter sets the user's name input from the main
     * class into the instance variable name so that it can be used throughout
     * the entirety of this class to refer to the user by their 
     * inputted name from the main class.
     */
    public void randomDecision(String userName) {
        Random var = new Random();
        int scale = 1 + var.nextInt(4);
        name = userName;
        if (scale >= 2) {
            JOptionPane.showMessageDialog(null, "Player goes first.");
            playerCharacter = 'X';
            computerCharacter = 'O';
            player(name);
        } else if (scale <= 2) {
            JOptionPane.showMessageDialog(null, "Computer goes first.");
            computerCharacter = 'X';
            playerCharacter = 'O';
            computer();
        }
    }
    /**
     * This is the player method. It takes the user's input from String
     * userGuess and based on that sets the arrays elements to the 
     * playerCharacter which was determined based on who goes first randomly.
     * The String boardUpdate displays the updated board based on which
     * position in the array the user inputted the playerCharacter. Then the
     * computer method will be called so that the computer can go.
     * It will keep going until either the user or computer wins. Then the 
     * boolean keepPlaying will be set to false to stop the program from
     * running. The user will asked whether they want to play again. If they
     * input yes the program will run again from. the randomDecision method.
     * Else the program ends.
     * @param name is the instance variable name so that it can be used 
     * throughout the entirety of this class to refer to the user by their 
     * inputted name from the main/driver class.
     */
    public void player(String name) {
    
        while (keepPlaying) {         
            /*
             The user prompt to tell user where and in what format to put their
             selected row and column in.
            */
            String userGuess = JOptionPane.showInputDialog(name + ", where would"
                    + " you"
                    + " like to input " + playerCharacter + "." + " Input in"
                    + "following format. Input a number ranging from 1-9."
                    + "\n1 = row 1, column 1 "                                                                                      
                    + "\n2 = row 1, " + "column 2. "
                    + "\n3 = row 1, column 3" + "\n4 = row 2, column 1" + 
                      "\n5 = row 2, column 2"
                    + "\n6 = row 2, column 3" + "\n7 = row 3, column 1" + 
                      "\n8 = row 3, column 2"
                    + "\n9 = row 3, column 3"
                    + "\nEx: If you want row 1, column 1, then input the "
                    + "number 1.");
           
            // If user selects the number 1 for row 1, column 1. Same applies
            // for user choice up to the number 9 which is row 3, column 3.
            if (userGuess.equals("1")) {
                   // Check if value is empty first.
                if (arr[0][0] == 0) {
                   // Then set the value to the playerCharacter.
                    arr[0][0] = playerCharacter;
                    lastToPlay = 'p';
                } else {
                    /*
                     If user attempts to input their character in a position
                     that has already been taken either by the user or computer
                     then display this error message.
                    */
                    JOptionPane.showMessageDialog(null, name + ", you cannot "
                            + "input here try "
                            + "again.");
                    // Call the player method again to give user second chance.
                    player(name);
                }
            } else if (userGuess.equals("2")) {
                if (arr[0][1] == 0) {
                    arr[0][1] = playerCharacter;
                    lastToPlay = 'p';
                } else {
                    JOptionPane.showMessageDialog(null, name + ", you cannot "
                            + "input here try "
                            + "again.");
                    player(name);
                }
            } else if (userGuess.equals("3")) {
                if (arr[0][2] == 0) {
                    arr[0][2] = playerCharacter;
                    lastToPlay = 'p';
                } else {
                    JOptionPane.showMessageDialog(null, name + ", you cannot "
                            + "input here try "
                            + "again.");
                    player(name);
                }
            } else if (userGuess.equals("4")) {
                if (arr[1][0] == 0) {
                    arr[1][0] = playerCharacter;
                    lastToPlay = 'p';
                } else {
                    JOptionPane.showMessageDialog(null, name + ", you cannot "
                            + "input here try "
                            + "again.");
                    player(name);
                }
            } else if (userGuess.equals("5")) {
                if (arr[1][1] == 0) {
                    arr[1][1] = playerCharacter;

                } else {
                    JOptionPane.showMessageDialog(null, name + ", you cannot "
                            + "input here try "
                            + "again.");
                    player(name);
                }
            } else if (userGuess.equals("6")) {
                if (arr[1][2] == 0) {
                    arr[1][2] = playerCharacter;
                    lastToPlay = 'p';
                } else {
                    JOptionPane.showMessageDialog(null, name + ", you cannot "
                            + "input here try "
                            + "again.");
                    player(name);
                }
            } else if (userGuess.equals("7")) {
                if (arr[2][0] == 0) {
                    arr[2][0] = playerCharacter;
                    lastToPlay = 'p';
                } else {
                    JOptionPane.showMessageDialog(null, name + ", you cannot "
                            + "input here try "
                            + "again.");
                    player(name);
                }
            } else if (userGuess.equals("8")) {
                if (arr[2][1] == 0) {
                    arr[2][1] = playerCharacter;
                    lastToPlay = 'p';
                } else {
                    JOptionPane.showMessageDialog(null, name + ", you cannot "
                            + "input here try "
                            + "again.");
                    player(name);
                }
            } else if (userGuess.equals("9")) {
                if (arr[2][2] == 0) {
                    arr[2][2] = playerCharacter;
                    lastToPlay = 'p';
                } else {
                    JOptionPane.showMessageDialog(null, name + ", you cannot "
                            + "input here try "
                            + "again.");
                    player(name);
                }
            }
             // Displays the updated board.
             String boardUpdate = JOptionPane.showInputDialog(" " + arr[0][0] +
                    " | " + arr[0][1] + " | "
                    + arr[0][2] + "\n ---------"
                    + "\n " + arr[1][0] + " | " + arr[1][1] + " | " + arr[1][2]
                    + "\n ---------"
                    + "\n " + arr[2][0] + " | " + arr[2][1] + " | " + arr[2][2]
                    + "\n Input nothing this is just here to show you the board."
                    + "\n Press enter key to continue."
                    );
            // Check winning condition.
            if (winCondition()) {
                if(lastToPlay == 'p'){
                   JOptionPane.showMessageDialog(null, "Player has won!"); 
                   keepPlaying = false;
                   if (keepPlaying == false) {
                    playAgain();
                }
                }
                else if(lastToPlay == 'c'){
                   JOptionPane.showMessageDialog(null, "Computer has won!");
                   keepPlaying = false;
                   if (keepPlaying == false) {
                    playAgain();
                }
                } 
            }
            // Check whether the board is full or not.
            if (checkFullBoard()) {
                JOptionPane.showMessageDialog(null, "It's a tie. No one won!!!!"
                );
                keepPlaying = false;
                if (keepPlaying == false) {
                    playAgain();
                }
            }
            // While keepPlaying is true, computer's turn.
            if (keepPlaying) {
                computer();
            }
        }
    }
    
    /**
     * This is the computer method. This method randomly generates the row and
     * column in which the computer will input the computerCharacter. This 
     * random number will be generated until the row and column number that is
     * generated is empty (does not have a computerCharacter or playerCharacter
     * in that generated row or column). Then the player method will be called
     * do that the player can go next. NOTE: \u0000 is the default value
     * of a character array and that is what I am using to check whether the
     * array position is empty or not.
     */
    public void computer() {
        
        Random obj = new Random();
        /*
         Creates random number for the row ranging from 0 to 2 based on 
         indices of the array.
        */
        int row = obj.nextInt(3);
        /*
         Creates random number for the column ranging from 0 to 2 based on 
         indices of the array.
        */
        int col = obj.nextInt(3);
        /*
        The integer to be displayed to the user when the random row number is
        selected by the computer.
        */
        int displayRow;
         /*
        The integer to be displayed to the user when the random column number is
        selected by the computer.
        */
        int displayColumn;

        while (arr[row][col] != '\u0000') {
            /*
            While the row number and column number is not empty, keep generating
            the random number until the row and column number generated is 
            referring to an empty spot.
            */
            row = obj.nextInt(3);
            col = obj.nextInt(3);
        }
           /*
            Adding one to the randomly generated row and column since the 
            user thinks of the array positions from 1 - 3 scale whereas 
            computer is doing it from indices 0 - 2. This is done just to 
            display to the user where the computer inserted their character
            based on 1 - 3 scale for rows and columns.
           */
         displayRow = row + 1;
         displayColumn = col + 1;
         
        JOptionPane.showMessageDialog(null, "Computer inputs " + 
                computerCharacter + " at " + "Row: " + displayRow + " Col: " + 
                displayColumn);
       
        arr[row][col] = computerCharacter;
        lastToPlay = 'c';
         // Displays the updated board.
         String boardUpdate = JOptionPane.showInputDialog(" " + arr[0][0] +
                    " | " + arr[0][1] + " | "
                    + arr[0][2] + "\n ---------"
                    + "\n " + arr[1][0] + " | " + arr[1][1] + " | " + arr[1][2]
                    + "\n ---------"
                    + "\n " + arr[2][0] + " | " + arr[2][1] + " | " + arr[2][2]
                    + "\n Input nothing this is just here to show you the board."
                    + "\n Press enter key to continue."
                    );
        // Check winning conditions.
        if (winCondition()) {
                if(lastToPlay == 'p'){
                   JOptionPane.showMessageDialog(null, "Player has won!"); 
                   keepPlaying = false;
                   if (keepPlaying == false) {
                    playAgain();
                }
                }
                else if(lastToPlay == 'c'){
                   JOptionPane.showMessageDialog(null, "Computer has won!");
                   keepPlaying = false;
                   if (keepPlaying == false) {
                    playAgain();
                }
                } 
            }
        // Check whether board is full or not.
          if (checkFullBoard()) {
                JOptionPane.showMessageDialog(null, "It's a tie. No one won!!!!"
                );
                keepPlaying = false;
                if (keepPlaying == false) {
                    playAgain();
                }
            }
        // While keepPlaying is true, player's turn.
        if(keepPlaying){
           player(name);
        }
    }
    
    /**
     * This is the winCondition method. This method checks the winning 
     * conditions of the game which are vertical, horizontal, and diagonals.
     * @return true if any of the winning conditions are met. Else, return 
     * false if none of the winning conditions were met.
     */
    public boolean winCondition() {
        // Vertical (rows) win condition.
        for (int i = 0; i < arr.length; i++) {                            
            if ((arr[i][0] == arr[i][1]) && (arr[i][1] == arr[i][2]) 
                    && arr[i][0] != '\u0000') {
                return true;
            }
        }
        // Horizontal (columns) win condition.
        for (int j = 0; j < arr.length; j++) {
            if ((arr[0][j] == arr[1][j]) && (arr[1][j] == arr[2][j]) 
                    && arr[0][j] != '\u0000') {
                return true;
            }
        }
        // Following 2 conditionals for the diagonal checks.
        if ((arr[0][0] == arr[1][1]) && (arr[1][1] == arr[2][2]) 
                && arr[0][0] != '\u0000') {
            return true;
        }
        if ((arr[0][2] == arr[1][1]) && (arr[1][1] == arr[2][0]) 
                && arr[0][2] != '\u0000') {
            return true;
        }
        return false;
    }
    
    /**
     * This is the checkFullBoard method. It checks to see whether all of the
     * array positions are filled or not.
     * @return true if all of the elements of the array have some "value" in 
     * them. Else, return false if there is a single position that is empty.
     */
    public boolean checkFullBoard() {
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                if (arr[i][j] == '\u0000') {
                    return false;
                }
            }
        }
        return true;
    }
    
    /**
     * This is the playAgain method. This method asks the user if they want
     * to play again. If the user inputs yes then the board is reset by the
     * resetBoard method and then the randomDecision method is called to 
     * run the program again. Else, if the user inputs no, then a thanks for 
     * playing prompt is displayed followed by the termination of the program.
     */
    public void playAgain() {
        String choice = JOptionPane.showInputDialog("Would you like to "
                + "play again. Input yes or no.");
        if (choice.equalsIgnoreCase("yes")) {
            keepPlaying = true;
            resetBoard();
            // Call this method to start the game over from the beginning.
            randomDecision(name);
        } else {
            keepPlaying = false;
            JOptionPane.showMessageDialog(null, "Thanks for playing.");
            keepPlaying = false;
            // Used to exit the program once user selects no.
            System.exit(0);
        }
    }
    
    /**
     * This is the resetBoard method. This method resets the board with the
     * default values of the character array by using a nested for loop to 
     * access the rows and columns of the array.
     */
    public void resetBoard() {
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                /*
                 Fill each position in the array with the default value of the
                 character array.
                */
                arr[i][j] = '\u0000';
            }
        }
    }
}
