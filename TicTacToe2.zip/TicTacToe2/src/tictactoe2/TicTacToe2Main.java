/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tictactoe2;

import java.util.Random;
import javax.swing.JOptionPane;

//******************************************************************************
// STUDENT NAME: Rohan Shanbhag
// FIU EMAIL: rshan026@fiu.edu
// CLASS: COP 2210 – Fall 2019
// ASSIGNMENT # 5
// DATE: 12/1/2019
//
// I hereby swear and affirm that this work is solely my own, and not the work 
// or the derivative of the work of someone else, except as outlined in the 
// assignment instructions.
//******************************************************************************

public class TicTacToe2Main {

    public static void main(String[] args) {
        // Creating object of TicTacToe2 class to use its methods.
        TicTacToe2 obj = new TicTacToe2();
        String userName = JOptionPane.showInputDialog("Welcome to tic tac toe."
                + " Input your name.");
        // Prompt that introduces rules to the user.
        JOptionPane.showMessageDialog(null, "Rules: You must input either X or "
                + "O. "
                + "Who goes" + " first will be decided randomly."
                + "\nWhen inputting X or O " + " put it in the format shown "
                + "later. "
                + "Remember"
                + " it is a 3 by 3 grid.");
        /*
        Calling the random decision method from the TicTacToe class to start
        the program.
        */
        obj.randomDecision(userName);
    }

}
