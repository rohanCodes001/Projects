/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tictactoe2;

import java.util.Random;
import javax.swing.JOptionPane;

/**
 *
 * @author smart
 */
public class TicTacToe2Main {
    public static void main(String[] args) {
        TicTacToe2 obj = new TicTacToe2();
         String name = JOptionPane.showInputDialog("Welcome to tic tac toe."
            + " Input your name.");
    JOptionPane.showMessageDialog(null, name + ", Rules: You must input either X or O. "
            + "Who goes" + " first will be decided randomly." +
            "\nWhen inputting X or O " + " put it in the format shown later. Remember"
            + " it is a 3 by 3 grid.");
       
    
       
         obj.randomDecision(name);
        }
       
}

