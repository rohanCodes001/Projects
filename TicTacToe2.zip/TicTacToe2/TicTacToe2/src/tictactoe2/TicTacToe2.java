/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tictactoe2;

import java.util.Random;
import javax.swing.JOptionPane;

/**
 *
 * @author smart
 */
public class TicTacToe2 {

    /**
     * @param args the command line arguments
     */
    char[][] arr = new char[3][3];
    char playerCharacter = ' ';
    char computerCharacter = ' ';
    
    boolean keepPlaying ; 
    
    public TicTacToe2()
    {
        keepPlaying = true ; 
    }

    public void randomDecision() {
        Random var = new Random();
        int scale = 1 + var.nextInt(4);
        if (scale >= 2) {
            JOptionPane.showMessageDialog(null, "Player goes first.");
            playerCharacter = 'X';
            computerCharacter = 'O';
            player();
        } else if (scale <= 2) {
            JOptionPane.showMessageDialog(null, "Computer goes first.");
            computerCharacter = 'X';
            playerCharacter = 'O';
            computer();
        }
    }

    public void player() {
        //  for (int i = 0; i < arr.length; i++) {
        // for (int j = 0; j < arr[i].length; j++) {
        while (keepPlaying) {
            String userGuess = JOptionPane.showInputDialog("Where would you"
                    + " like to input " + playerCharacter + "." + " Input in"
                    + "following format. \n1 = row 1, column 1 \n2 = row 1, column 2"
                    + "\n3 = row 1, column 3" + "\n4 = row 2, column 1" + "\n5 = row 2, column 2"
                    + "\n6 = row 2, column 3" + "\n7 = row 3, column 1" + "\n8 = row 3, column 2"
                    + "\n9 = row 3, column 3");
            if (userGuess.equals("1")) {
                if (arr[0][0] == 0) {
                    arr[0][0] = playerCharacter;

                } else {
                    JOptionPane.showMessageDialog(null, "You cannot input here try "
                            + "again.");
                    player();
                }
            } else if (userGuess.equals("2")) {
                if (arr[0][1] == 0) {
                    arr[0][1] = playerCharacter;

                } else {
                    JOptionPane.showMessageDialog(null, "You cannot input here try "
                            + "again.");
                    player();
                }
            } else if (userGuess.equals("3")) {
                if (arr[0][2] == 0) {
                    arr[0][2] = playerCharacter;

                } else {
                    JOptionPane.showMessageDialog(null, "You cannot input here try "
                            + "again.");
                    player();
                }
            } else if (userGuess.equals("4")) {
                if (arr[1][0] == 0) {
                    arr[1][0] = playerCharacter;

                } else {
                    JOptionPane.showMessageDialog(null, "You cannot input here try "
                            + "again.");
                    player();
                }
            } else if (userGuess.equals("5")) {
                if (arr[1][1] == 0) {
                    arr[1][1] = playerCharacter;

                } else {
                    JOptionPane.showMessageDialog(null, "You cannot input here try "
                            + "again.");
                    player();
                }
            } else if (userGuess.equals("6")) {
                if (arr[1][2] == 0) {
                    arr[1][2] = playerCharacter;

                } else {
                    JOptionPane.showMessageDialog(null, "You cannot input here try "
                            + "again.");
                    player();
                }
            } else if (userGuess.equals("7")) {
                if (arr[2][0] == 0) {
                    arr[2][0] = playerCharacter;

                } else {
                    JOptionPane.showMessageDialog(null, "You cannot input here try "
                            + "again.");
                    player();
                }
            } else if (userGuess.equals("8")) {
                if (arr[2][1] == 0) {
                    arr[2][1] = playerCharacter;

                } else {
                    JOptionPane.showMessageDialog(null, "You cannot input here try "
                            + "again.");
                    player();
                }
            } else if (userGuess.equals("9")) {
                if (arr[2][2] == 0) {
                    arr[2][2] = playerCharacter;

                } else {
                    JOptionPane.showMessageDialog(null, "You cannot input here try "
                            + "again.");
                    player();
                }
                //}
                //}
            }
            if (winCondition()) {
                JOptionPane.showMessageDialog(null, "Player " + "whoever" + " has won!");
                keepPlaying = false;
               // break;
            }
            if (checkFullBoard()) {
                JOptionPane.showMessageDialog(null, "It's a tie. No one won!!!!");
                keepPlaying = false ; 
                //break;
            }
            
            if(keepPlaying){
                computer();
            }
        }
    }

    public void computer() {
        Random obj = new Random();
        int row = obj.nextInt(3);
        int col = obj.nextInt(3);
        int displayRow = row + 1;
        int displayColumn = col + 1;
        //for (int i = 0; i < arr.length; i++) {
        //for (int j = 0; j < arr[i].length; j++) {
        while( arr[row][col] != '\u0000')
        {
            row = obj.nextInt(3) ;
            col = obj.nextInt(3) ;
        }
        JOptionPane.showMessageDialog(null, "Computer inputs " + computerCharacter + " at " + "Row: " + displayRow + " Col: " + displayColumn);
        
        arr[row][col] = computerCharacter;
     
        player();
        //}
        //}
    }

    public boolean winCondition() {
        for (int i = 0; i < arr.length; i++) {                             //should not be empty
            if ((arr[i][0] == arr[i][1]) && (arr[i][1] == arr[i][2]) && arr[i][0] != '\u0000' ) {
                return true;
            }
        }
        for (int j = 0; j < arr.length; j++) {
            if ((arr[0][j] == arr[1][j]) && (arr[1][j] == arr[2][j]) && arr[0][j] != '\u0000') {
                return true;
            }
        }
        //following 2 conditionals for the diagonal checks.
        if ((arr[0][0] == arr[1][1]) && (arr[1][1] == arr[2][2]) && arr[0][0] != '\u0000') {
            return true;
        }
        if ((arr[0][2] == arr[1][1]) && (arr[1][1] == arr[2][0]) && arr[1][1] != '\u0000') {
            return true;
        }
        return false;
    }

    public boolean checkFullBoard() {
        for (int i = 0; i < arr.length; i++) {
            for (int j = 0; j < arr[i].length; j++) {
                if (arr[i][j] == '\u0000') {
                    return false ; 
                }
            }
        }
        return true ; 
    }
}
