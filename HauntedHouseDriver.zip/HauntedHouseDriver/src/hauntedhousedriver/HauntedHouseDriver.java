/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hauntedhousedriver;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

//******************************************************************************
// PANTHERID:  #3849219
// CLASS: COP 2210 – Fall 2019
// ASSIGNMENT # 3
// DATE: 10/29/19
//
// I hereby swear and affirm that this work is solely my own, and not the work 
// or the derivative of the work of someone else.
//******************************************************************************

public class HauntedHouseDriver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*
        This is the driver class where all of the methods for floor 1 and floor
        2 of the haunted house will be executed depending on the user's inital 
        choice of whether to go to the dining room, living room, or stairs.
        */
        JOptionPane.showMessageDialog(null, "Important: When you pick up an"
                + " item, the game ends. Also the 6 starting points are as"
                + " follows: \nLiving room, dining room, stairs, master bedroom,"
                + " bedroom 1, and bedroom 2."    
                + "\nBacktracking can only be performed once you are inside one"
                + " of these 6 starting points.");
        
        String name = JOptionPane.showInputDialog("Enter your name to begin.");
        /*
        The user's name is stored in this String variable so that it can be
        passed on as parameters to the constructor of floor 1 object 1 and 
        floor 2 object 2. Through this process, the user will be referred to as
        the name they provided in this String.
        */
        ImageIcon iconOne = new ImageIcon("GameStart.png");
        /*
        This image displays to the user where they will start every time they
        run the program. It is stored in the ImageIcon object of the ImageIcon
        class.
        */
        Floor1 obj = new Floor1(name);
        // Creating a floor 1 object so that we can use that class's methods.
        Floor2One obj3 = new Floor2One(name);
        // Creating a floor 2 object so that we can use that class's methods.
        JOptionPane.showMessageDialog(null,name + ", you are "
        + "starting from the front door.", 
        name ,JOptionPane.INFORMATION_MESSAGE, iconOne);
        String choice = JOptionPane.showInputDialog("Hello, " + name + "." + ""
              + " Would you like to go to the living room or dining room."
              + "\nEnter L for living room, D for dining Room, or S for stairs."
              + "");
        /*
        Asking the user where they would like to go. Their options are living 
        room, dining room, and stairs. The following conditional statements will
        be executed depending on what the user choose from the 3 options.
        */
        if (choice.equalsIgnoreCase("L")) {
            obj.livingRoom(choice); 
            /*
            If the user selected living room, then execute the living room 
            method of the floor one class while passing in their choice as
            a parameter for that method to function properly.
            */
        } else if (choice.equalsIgnoreCase("D")) {
            obj.diningRoom(choice);
            /*
            If the user selected dining room, then execute the dining room 
            method of the floor one class while passing in their choice as
            a parameter for that method to function properly.
            */
        } else if (choice.equalsIgnoreCase("S")) {
            String choiceTwo = JOptionPane.showInputDialog(name + ", you "
                    + "are climbing the stairs. You have 3 options. Either go"
                    + " to the master bedroom, bedroom 1, or bedroom 2.\nInput "
                    + "MB for master bedroom, B1 for bedroom 1, or B2 for "
                    + "bedroom 2.");
             /*     
            If the user selected the stairs, then execute another prompt that
            asks the user once they reach floor 2 through the stairs, where they 
            would like to proceed to next. The next 3 options presented in this
            prompt are master bedroom, bedroom 1, and bedroom 2. The following
            conditional statements will be executed depending on what the user
            choose from the 3 options.
            */
            if (choiceTwo.equalsIgnoreCase("MB")) {
                obj3.masterBedroomRoom(choiceTwo);
            /*
            If the user selected master bedroom, then execute the master bedroom 
            method of the floor 2 class while passing in their choice as
            a parameter for that method to function properly.
            */
            } else if (choiceTwo.equalsIgnoreCase("B1")) {
                obj3.bedroomOneRoom(choiceTwo);
            /*
            If the user selected bedroom 1, then execute the bedroom one
            method of the floor 2 class while passing in their choice as
            a parameter for that method to function properly.
            */
            } else if (choiceTwo.equalsIgnoreCase("B2")) {
                obj3.bedroomTwoRoom(choiceTwo);
            /*
            If the user selected bedroom 2, then execute the bedroom 2 
            method of the floor 2 class while passing in their choice as
            a parameter for that method to function properly.
            */
  
            }
        }
        JOptionPane.showMessageDialog(null, name + ", thanks for playing!!!");
    }
   }

