package hauntedhousedriver;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//******************************************************************************
// PANTHERID:  #3849219
// CLASS: COP 2210 – Fall 2019
// ASSIGNMENT # 3
// DATE: 10/29/19
//
// I hereby swear and affirm that this work is solely my own, and not the work 
// or the derivative of the work of someone else.
//******************************************************************************
public class Floor1 {
      /*
    This class contains all of the instance variabes and methods for floor 1 of 
    the haunted house.
    */
    private String name;  // The name that the user inputs will be stored here.
    private String arr[] = {"chest", "mirror", "shower", "candelabra",
        "frying pan", "spatula", "recipe box", "god tier broom"};
    int x = 0;
    /*
    The array of items for floor 1 which consist of the dining room, living
    room, bathroom, pantry, and kitchen items.
    */
    ImageIcon iconOne = new ImageIcon("EndLivingRoom.png");
    ImageIcon iconTwo = new ImageIcon("EndBathroom.png");
    ImageIcon iconThree = new ImageIcon("EndDiningRoom.png");
    ImageIcon iconFour = new ImageIcon("EndKitchen.png");
    ImageIcon iconFive = new ImageIcon("EndPantry.png");
    /*
    The images are stored in the ImageIcon objects of the ImageIcon class to be
    displyed to the user where they ended the game.
    */
    public Floor1(String name) {
        this.name = name;
    }
   /*
    The constructor used to get the user's name so that it can be used to refer
    to them throughot the entire program.
    */
    public void livingRoom(String input) {
        while(x == 0){
        if (input.equalsIgnoreCase("L")) {
            String firstDecision = JOptionPane.showInputDialog(name
                  + ", you are in the"
                  + " living room. Would you like to explore the chest or go to"
                  + " the bathroom.\nEnter I for item or B for bathroom.");
            /*
            If the user is in the living room then they can either go to the 
            bathroom or pick up an item. The next conditional statement accounts
            for the item.
            */
            if (firstDecision.equalsIgnoreCase("I")) {
                JOptionPane.showMessageDialog(null, "A ghost has killed you!"
                        + " Better luck next time.");
                JOptionPane.showMessageDialog(null, "Your backpack contains "
                        + arr[0] + ".");
                JOptionPane.showMessageDialog(null, name + ", you ended at "
        + "the living room.", name ,JOptionPane.INFORMATION_MESSAGE, iconOne);
                /*
                If the user picks up the item then the ghost kills them and the 
                item which in this case is the chest, is added to the backpack.
                The user is then shown a picture of where they ended which in
                this case is the living room.
                */
                x = 1;
            } else if (firstDecision.equalsIgnoreCase("B")) {
                String secondDecision = JOptionPane.showInputDialog(name
                        + ", you are in"
                        + " the bathroom. You can choose to explore 2 items. "
                        + "Those" + " being mirror or shower."
                        + "\nEnter M for mirror, S for"
                        + " shower, or enter key to go back to living room.");
                /*
                If the user is in the bathroom then they can either explore
                one of 2 items. Those being the mirror or the shower. The next
                sequence of conditional statements accounts for what happens
                if the user selects either of those 2 items.
                */
                if (secondDecision.equalsIgnoreCase("M")) {
                    JOptionPane.showMessageDialog(null, "See a bloody face "
                            + "looking "
                            + "back at you. It randomly kills you!" 
                            + " The end.");
                    JOptionPane.showMessageDialog(null, "Your backpack "
                            + "contains " + arr[1] + ".");
                    JOptionPane.showMessageDialog(null, name + ", you ended in "
        + "the bathroom.", name ,JOptionPane.INFORMATION_MESSAGE, iconTwo);
                    x = 1;
                     /*
                    If the user explores the mirror then the bloody face kills
                    them and the item which in this case is mirror, is added 
                    to the backpack. The user is then shown a picture of where 
                    they ended which in this case is the bathroom.
                     */
                } else if (secondDecision.equalsIgnoreCase("S")) {
                    JOptionPane.showMessageDialog(null, "The steaming water"
                            + " from the shower kills you!" + " The end.");
                    JOptionPane.showMessageDialog(null, "Your backpack "
                            + "contains " + arr[2] + ".");
                    JOptionPane.showMessageDialog(null, name + ", you ended in "
        + "the bathroom.", name ,JOptionPane.INFORMATION_MESSAGE, iconTwo);
                    x = 1;
                      /*
                    If the user explores the shower then the steaming water 
                    kills them and the item which in this case is shower, is 
                    added to the backpack. The user is then shown a picture of 
                    where they ended which in this case is the bathroom.
                     */
                }
            }
        }
    }
   }
    public void diningRoom(String input) {
        while(x == 0){
        if (input.equalsIgnoreCase("D")) {
            String firstDecision = JOptionPane.showInputDialog(name
                    + ", you are in the"
                    + " dining room. Would you like to explore the candelabra "
                    + "or" + " go to the kitchen.\nInput K for kitchen or C for"
                    + " candelbra.");
            /*
            If the user is in the dining room then they can either go to the 
            kitchen or explore the candelbra. The next conditional statement 
            accounts for the candelbra.
            */
            if (firstDecision.equalsIgnoreCase("C")) {
                JOptionPane.showMessageDialog(null, "The death shadow chases "
                        + "you" + " till you die." + " The end.");
                JOptionPane.showMessageDialog(null, "Your backpack contains "
                        + arr[3] + ".");
                JOptionPane.showMessageDialog(null, name + ", you ended at "
        + "the dining room.", name ,JOptionPane.INFORMATION_MESSAGE, iconThree);
                x = 1;
                 /*
                If the user explores the candelbra then the death shadow chases 
                you until you die and the item which in this case is candelbra, 
                is added to the backpack. The user is then shown a picture of 
                where they ended which in this case is the dining room.
                */
            } else if (firstDecision.equalsIgnoreCase("K")) {
                String secondDecision = JOptionPane.showInputDialog(name + ", "
                        + "you are in the kitchen. You can either go to the "
                        + "pantry or explore 2 items." + " \nInput I for item"
                        + ", P for pantry, or enter key to go back to kitchen.");
                     /*
                    If the user is in the kitchen then they can either go to
                    the pantry or explore one of 2 items. The next conditional 
                    statements account for the 2 items option.
                    */
                if (secondDecision.equalsIgnoreCase("I")) {
                    String itemDecision = JOptionPane.showInputDialog("You have"
                            + " 2 "
                            + "items to explore. "
                            + "Pick between the frying pan and"
                            + " the spatula. \nInput FP for frying pan, "
                            + "SP for "
                            + "spatula, or enter key to go back to the kitchen.");
                        /*
                        If the user chose to explore one of the 2 items then they 
                        can either explore the spatula or the frying pan.
                        The next conditional statements account for either of 
                        the items the user choose.
                        */
                    if (itemDecision.equalsIgnoreCase("FP")) {
                        JOptionPane.showMessageDialog(null, "The invisible "
                                + "frying pan hits"
                                + " you till you die." + " The end.");
                        JOptionPane.showMessageDialog(null, "Your backpack "
                                + "contains " + arr[4] + ".");
                        JOptionPane.showMessageDialog(null, name + ", you ended"
                                + " at "
        + "the kitchen.", name ,JOptionPane.INFORMATION_MESSAGE, iconFour);
                        x = 1;
                        /*
                        If the user explores the frying pan then the pan kills
                        them and the item which in this case is the frying pan, 
                        is added to the backpack. The user is then shown a 
                        picture of where they ended which in this case is the 
                        kitchen.
                        */
                    } else if (itemDecision.equalsIgnoreCase("SP")) {
                        JOptionPane.showMessageDialog(null, "The spatula chases"
                                + " you but by accident it hits the wall and "
                                + "you" + " escape." + " The end.");
                        JOptionPane.showMessageDialog(null, "Your backpack "
                                + "contains " + arr[5] + ".");
                        JOptionPane.showMessageDialog(null, name + ", you ended"
                                + " at "
        + "the kitchen.", name ,JOptionPane.INFORMATION_MESSAGE, iconFour);
                        x = 1;
                    }
                        /*
                        If the user explores the spatula then the spatula hits
                        the wall and the user escapes. The item which in this 
                        case is the spatula is added to the backpack. The user 
                        is then shown a picture of where they ended which in 
                        this case is the kitchen.
                        */
                } else if (secondDecision.equalsIgnoreCase("P")) {
                    String itemDecisionTwo = JOptionPane.showInputDialog(name + 
                          ","
                        + " you can pick between the god tier broom or "
                        + "recipe box."
                        + " \nInput R for recipe box, GTB for "
                        + "god tier broom, or enter key to go back to kitchen.");
                    /*
                    If the user is in the pantry then they can either
                    explore one of 2 items. Those being the recipe box or the
                    broom. The next conditional statements account for the 2 
                    items option.
                    */
                    if (itemDecisionTwo.equalsIgnoreCase("R")) {
                        JOptionPane.showMessageDialog(null, "You cook the recipe"
                                + " that the"
                                + " box tells you. "
                                + "It destroys your heart and you die!"
                                + " The end.");
                        JOptionPane.showMessageDialog(null, "Your backpack "
                                + "contains " + arr[6] + ".");
                        JOptionPane.showMessageDialog(null, name + ", you ended"
                                + " at "
        + "the pantry.", name ,JOptionPane.INFORMATION_MESSAGE, iconFive);
                        x = 1;
                        /*
                        If the user explores the recipe box then the 
                        the user cooks the recipe and dies. The item which in
                        this case is the recipe box is added to the backpack. 
                        The user is then shown a picture of where they ended 
                        which in this case is the pantry.
                        */
                    } else if (itemDecisionTwo.equalsIgnoreCase("GTB")) {
                        JOptionPane.showMessageDialog(null, "The god tier broom"
                                + " takes you"
                                + " away and you escape!" + " The end.");
                        JOptionPane.showMessageDialog(null, "Your backpack"
                                + " contains "
                                + arr[7] + ".");
                        JOptionPane.showMessageDialog(null, name + ", you ended"
                                 + " at "
        + "the pantry.", name ,JOptionPane.INFORMATION_MESSAGE, iconFive);
                        x = 1;
                        /*
                        If the user explores the broom then the broom aids you
                        in your escape. The item which in this case is the broom
                        is added to the backpack. The user is then shown a 
                        picture of where they ended which in this case is the
                        pantry.
                        */
                    }
                }
            }
        }
    }
  }
}
