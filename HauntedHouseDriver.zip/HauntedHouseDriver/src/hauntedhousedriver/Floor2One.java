package hauntedhousedriver;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//******************************************************************************
// PANTHERID:  #3849219
// CLASS: COP 2210 – Fall 2019
// ASSIGNMENT # 3
// DATE: 10/29/19
//
// I hereby swear and affirm that this work is solely my own, and not the work 
// or the derivative of the work of someone else.
//******************************************************************************
public class Floor2One {
    /*
    This class contains all of the instance variabes and methods for floor 2 of 
    the haunted house.
    */
    private String name; // The name that the user inputs will be stored here.
    private String arr[] = {"chest", "mirror", "shower", "candelabra",
        "frying pan", "spatula", "recipe box", "god tier broom", "jewelry box",
        "oil lamp", "master bathroom shower", "rocking chair", "window", "comb",
        "toothbrush", "doll house", "dresser"};
    int x = 0;
    /*
    The array of items for floor 2 which consist of the bedroom 1, bedroom 2,
    master bedroom, master bathroom, and bathroom items.
    */
    ImageIcon iconOne = new ImageIcon("EndMasterBedroom(2nd floor).png");
    ImageIcon iconTwo = new ImageIcon("EndMasterBathroom(2nd floor).png");
    ImageIcon iconThree = new ImageIcon("EndBedroom1(2nd floor).png");
    ImageIcon iconFour = new ImageIcon("EndBedroom2(2nd floor).png");
    ImageIcon iconFive = new ImageIcon("EndBathroom(2nd floor).png");
     /*
    The images are stored in the ImageIcon objects of the ImageIcon class to be
    displyed to the user where they ended the game.
    */
    public Floor2One(String name) {
        this.name = name;
    }
     /*
    The constructor used to get the user's name so that it can be used to refer
    to them throughout the entire program.
    */
    /**
     * 
     * @param input 
     */
    public void masterBedroomRoom(String input) {
        while(x == 0){
        if (input.equalsIgnoreCase("MB")) {
            String secondDecision = JOptionPane.showInputDialog(name + ", you "
                    + "are in the master bedroom. You can either explore the "
                    + "jewelry box or proceed to the the master bathroom."
                    + "\nInput JB for jewelry box or MBT for master bathroom.");
            /*
            If the user is in the master bedroom then they can either go to the 
            master bathroom or explore the jewelry box. The next conditional 
            statement accounts for the item.
            */
            if (secondDecision.equalsIgnoreCase("JB")) {
                JOptionPane.showMessageDialog(null, "A hope diamond pops up and"
                        + " because of the power of hope you escape!!");
                JOptionPane.showMessageDialog(null, "Your backpack contains "
                        + arr[8] + ".");
                JOptionPane.showMessageDialog(null, name + ", you ended at "
       + "the master bedroom.", name ,JOptionPane.INFORMATION_MESSAGE, iconOne);
                x = 1;
                /*
                If the user explores the jewelry box then the hope diamond
                emerges and allows you to escape. The jewelry box is added to 
                the backpack. The user is then shown a picture of where they 
                ended which in this case is the master bedroom.
                */
            } else if (secondDecision.equalsIgnoreCase("MBT")) {
                String thirdDecision = JOptionPane.showInputDialog(null, name
                      + ", you are in the master bathroom. You can choose to "
                      + "explore the oil lamp, shower, or go back to the master"
                      + " bedroom.\nInput OL for oil lamp"
                      + ", SH for shower, or enter key to go back to master"
                      + " bedroom.");
                /*
                If the user is in the master bathroom then they can either 
                explore one of 2 items. Those being the oil lamp or the shower.
                The following conditional statements account for the 2 items 
                option.
                */
                if (thirdDecision.equalsIgnoreCase("OL")) {
                    JOptionPane.showMessageDialog(null, "A genie pops up and"
                            + " grants " + "you 3 wishes. Input your 3 wishes "
                            + "in the following" + " dialog boxes.");
                    String firstWish = JOptionPane.showInputDialog("Input"
                            + " first " + "wish.");
                    String secondWish = JOptionPane.showInputDialog("Input "
                            + "second" + " wish.");
                    String thirdWish = JOptionPane.showInputDialog("Input "
                            + "third " + "wish.");
                    JOptionPane.showMessageDialog(null, "Your wishes are "
                           + "as follows."
                          + "\nWish 1: " + firstWish + "\nWish 2: " + secondWish
                  + "\nWish 3: " + thirdWish + "\nYour 3 wishes have magically "
                          + "teleported you outside of the house. You escape!");
                    JOptionPane.showMessageDialog(null, "Your backpack "
                            + "contains " + arr[9] + ".");
                    JOptionPane.showMessageDialog(null, name + ", you ended at "
      + "the master bathroom.", name ,JOptionPane.INFORMATION_MESSAGE, iconTwo);
                    x = 1;
                    /*
                    If the user explores the oil lamp then the genie appears and
                    allows the user to escape once they have inputted their 3 
                    wishes. The oil lamp is added to the backpack. The user is 
                    then shown a picture of where they ended which in this case
                    is the master bathroom.
                    */
                } else if (thirdDecision.equalsIgnoreCase("SH")) {
                    JOptionPane.showMessageDialog(null, "The shower makes "
                            + "you sing " + "to your death. The end!");
                    JOptionPane.showMessageDialog(null, "Your backpack "
                            + "contains " + arr[10] + ".");
                    JOptionPane.showMessageDialog(null, name + ", you ended at "
      + "the master bathroom.", name ,JOptionPane.INFORMATION_MESSAGE, iconTwo);
                    x = 1;
                    /*
                    If the user explores the shower then the shower forces you
                    to sing your death. The shower is added to the backpack. 
                    The user is then shown a picture of where they ended which 
                    in this case is the master bathroom.
                    */
                }
            }
        }
    }
  }
    public void bedroomOneRoom(String input) {
        while(x == 0){
        if (input.equalsIgnoreCase("B1")) {
            String secondDecisionTwo = JOptionPane.showInputDialog(name +
              ", you" + " are in bedroom 1. You can either "
            + "go to the bathroom or explore "
            + "items." + "\nInput BATH1 for bathroom or I2 to explore items.");
            /*
            If the user is in bedroom 1 then they can either go to the 
            bathroom or explore 1 of 2 items. The following conditional 
            statements account for the items options.
            */
            if (secondDecisionTwo.equalsIgnoreCase("I2")) {
                String itemDecision = JOptionPane.showInputDialog(name + 
                   ", you " + "have 2 items to choose from. "
                 + "Those being the rocking chair "
                 + "and the window.\nInput RC for rocking chair, WI for "
                 + "window, or enter key to go back to the bedroom");
                /*
                If the user is in bedroom 1 then they can either explore 1 of 2
                items. Those being the rocking chair or the window. The 
                following conditional statements account for the items options.
                */
                if (itemDecision.equalsIgnoreCase("RC")) {
                 JOptionPane.showMessageDialog(null, "The chair starts rocking "
                            + "and a ghost pops up and kills you. The end!");
                 JOptionPane.showMessageDialog(null, "Your backpack contains "
                            + arr[11] + ".");
                 JOptionPane.showMessageDialog(null, name + ", you ended at "
        + "the bedroom 1.", name ,JOptionPane.INFORMATION_MESSAGE, iconThree);
                 x = 1;
                    /*
                    If the user explores the rocking chair then a ghost appears
                    and kills the user. The rocking chair is then added to the 
                    backpack. The user is then shown a picture of where 
                    they ended which in this case is bedroom 1.
                    */
                } else if (itemDecision.equalsIgnoreCase("WI")) {
                   JOptionPane.showMessageDialog(null, "The grim reaper comes "
                            + "through the window and kills you! The end!");
                   JOptionPane.showMessageDialog(null, "Your backpack contains "
                            + arr[12] + ".");
                   JOptionPane.showMessageDialog(null, name + ", you ended at "
        + "the bedroom 1.", name ,JOptionPane.INFORMATION_MESSAGE, iconThree);
                   /*
                   If the user explores the window then the grim reaper appears
                   and kills the user. The window is then added to the 
                   backpack. The user is then shown a picture of where 
                   they ended which in this case is bedroom 1.
                   */
                   x = 1;
                }
            } else if (secondDecisionTwo.equalsIgnoreCase("BATH1")) {
                String thirdDecisionTwo = JOptionPane.showInputDialog(name + 
                        ", you" + " are in the bathroom. "
                      + "You can either explore the comb, the toothbrush, or "
                      + "go back to the bedroom.\nInput CB for comb, TB for "
                      + "toothbrush, or enter key to go back to the bedroom");
                    /*
                    If the user is in the bathroom then they can either explore  
                    1 of 2 items. Those being the comb or the toothbrush. 
                    The following conditional statements account for the items 
                    options.
                    */
                if (thirdDecisionTwo.equalsIgnoreCase("CB")) {
                  JOptionPane.showMessageDialog(null, "The comb combs your hair"
                         + " but then the comb drags you to the wall and chokes"
                         + " you to death. The end!");
                  JOptionPane.showMessageDialog(null, "Your backpack contains "
                            + arr[13] + ".");
                  JOptionPane.showMessageDialog(null, name + ", you ended at "
        + "the bathroom.", name ,JOptionPane.INFORMATION_MESSAGE, iconFive);
                  x = 1;
                  /*
                  If the user explores the comb then the comb chokes you to 
                  death. The comb is then added to the backpack. The user is 
                  then shown a picture of where they ended which in this case is
                  the bathroom.
                  */
                } else if (thirdDecisionTwo.equalsIgnoreCase("TB")) {
                   JOptionPane.showMessageDialog(null, "The toothbrush brushes"
                         + " your"
                         + " teeth so hard that they fall off and you"
                         + " die. The end!");
                   JOptionPane.showMessageDialog(null, "Your backpack contains "
                            + arr[14] + ".");
                   JOptionPane.showMessageDialog(null, name + ", you ended at "
        + "the bathroom.", name ,JOptionPane.INFORMATION_MESSAGE, iconFive);
                   x = 1;
                   /*
                   If the user explores the toothbrush then the toothbrush  
                   essentially kills you. The toothbrush is then added to the 
                   backpack. The user is then shown a picture of where they 
                   ended which in this case is the bathroom.
                   */
                }
            }
        }
    }
  }
    public void bedroomTwoRoom(String input) {
        while(x == 0){
        if (input.equalsIgnoreCase("B2")) {
            String fourthDecision = JOptionPane.showInputDialog(name + ", you"
               + " are in bedroom 2. You can either explore items or go to the "
               + "bathroom." + "\nInput BATH1 for bathroom or I2 for items.");
            /*
            If the user is in bedroom 2 then they can either go to the 
            bathroom or explore 1 of 2 items. The following conditional 
            statements account for the bathroom options. The ones after those 
            statements account for the items options.
            */
            if (fourthDecision.equalsIgnoreCase("BATH1")) {
                String fourthDecisionTwo = JOptionPane.showInputDialog(name +
                        ", you" + " are in the bathroom. You can either "
                    + "explore the comb, toothbrush, or go back to the bedroom."
                    + "\nInput CB for comb, TB for toothbrush, or enter key to"
                    + " go back to the bedroom.");
                 /*
                 If the user is in the bathroom then they can either explore  
                 1 of 2 items. Those being the comb or the toothbrush. 
                 The following conditional statements account for the items 
                 options.
                 */
                if (fourthDecisionTwo.equalsIgnoreCase("CB")) {
                   JOptionPane.showMessageDialog(null, "The comb combs your "
                         + "hair"
                         + " but then the comb drags you to the wall and chokes"
                         + " you to  death. The end!");
                   JOptionPane.showMessageDialog(null, "Your backpack contains "
                            + arr[13] + ".");
                   JOptionPane.showMessageDialog(null, name + ", you ended at "
        + "the bathroom.", name ,JOptionPane.INFORMATION_MESSAGE, iconFive);
                   x = 1;
                    /*
                    If the user explores the comb then the comb chokes you to 
                    death. The comb is then added to the backpack. The user is 
                    then shown a picture of where they ended which in this case
                    is the bathroom.
                    */
                } else if (fourthDecisionTwo.equalsIgnoreCase("TB")) {
                   JOptionPane.showMessageDialog(null, "The toothbrush brushes "
                            + "your"
                            + " teeth so hard that they fall off and you"
                            + " die. The end!");
                   JOptionPane.showMessageDialog(null, "Your backpack contains "
                            + arr[14] + ".");
                    JOptionPane.showMessageDialog(null, name + ", you ended at "
        + "the bathroom.", name ,JOptionPane.INFORMATION_MESSAGE, iconFive);
                    /*
                    If the user explores the toothbrush then the toothbrush  
                    essentially kills you. The toothbrush is then added to the 
                    backpack. The user is then shown a picture of where they 
                    ended which in this case is the bathroom.
                    */
                    x = 1;
                }
            } else if (fourthDecision.equalsIgnoreCase("I2")) {
                String fifthDecision = JOptionPane.showInputDialog(name +
                     ", you" + " can choose to explore "
                 + "either that doll house, dresser, or go back to the bedroom."
                 + "\nInput DH for doll house, DR for dresser, or enter key to"
                 + " go back to the bedroom.");
                /*
                If the user is in bedroom 2 then they can either explore 1 of 2
                items. Those being the doll house or the dresser. The 
                following conditional statements account for the items options.
                */
                if (fifthDecision.equalsIgnoreCase("DH")) {
                   JOptionPane.showMessageDialog(null, "The doll comes out of"
                          + " the " + "house and possesses you." + " The end!");
                   JOptionPane.showMessageDialog(null, "Your backpack contains "
                            + arr[15] + ".");
                   JOptionPane.showMessageDialog(null, name + ", you ended at "
        + "bedroom 2.", name ,JOptionPane.INFORMATION_MESSAGE, iconFour);
                   x = 1;
                   /*
                   If the user explores the doll house then the doll comes and
                   possesses you. The doll house is then added to the backpack. 
                   The user is then shown a picture of where they ended which 
                   in this case is the bedroom 2.
                   */
                } else if (fifthDecision.equalsIgnoreCase("DR")) {
                   JOptionPane.showMessageDialog(null, "The dresser falls on"
                            + " your head and you die. The end!");
                   JOptionPane.showMessageDialog(null, "Your backpack contains "
                            + arr[16] + ".");
                   JOptionPane.showMessageDialog(null, name + ", you ended at "
        + "bedroom 2.", name ,JOptionPane.INFORMATION_MESSAGE, iconFour);
                   x = 1;
                   /*
                   If the user explores the dresser then the dresser falls on 
                   you and you die. The dresser is then added to the backpack. 
                   The user is then shown a picture of where they ended which 
                   in this case is the bedroom 2.
                   */
                }
            }
        }
      }
    }
}
